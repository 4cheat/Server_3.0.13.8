select * from clients where client_login_name = :client_login_name:
 and client_login_password = :client_login_password:;